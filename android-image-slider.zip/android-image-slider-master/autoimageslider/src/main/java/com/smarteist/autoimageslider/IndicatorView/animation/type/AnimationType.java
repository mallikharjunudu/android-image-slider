package com.smarteist.autoimageslider.IndicatorView.animation.type;

public enum AnimationType {NONE, COLOR, SCALE, WORM, SLIDE, FILL, THIN_WORM, DROP, SWAP, SCALE_DOWN}
