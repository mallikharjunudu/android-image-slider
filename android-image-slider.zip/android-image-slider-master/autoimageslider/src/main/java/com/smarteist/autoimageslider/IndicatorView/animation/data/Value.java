package com.smarteist.autoimageslider.IndicatorView.animation.data;

public interface Value {/*empty*/}
